package com.coc.farmassistant

import androidx.compose.ui.test.assertTextEquals
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.coc.farmassistant.domain.model.Targets
import com.coc.farmassistant.domain.model.VerificationStatus
import com.coc.farmassistant.domain.usecase.ResourceEvaluator
import com.coc.farmassistant.ui.results.ResultCard
import com.coc.farmassistant.ui.theme.CocTheme
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class ResultCardTest {
    @get:Rule val rule = createComposeRule()

    private fun show(gold: Long?, elixir: Long?, v: VerificationStatus) {
        val outcome = ResourceEvaluator.evaluate(gold, elixir, v, Targets())
        rule.setContent { CocTheme { ResultCard(outcome, 1_700_000_000_000L) } }
    }

    @Test fun targetFoundIsShown() {
        show(1_200_000, 1_300_000, VerificationStatus.AUTO_VERIFIED)
        rule.onNodeWithTag("result_label").assertTextEquals("TARGET FOUND")
    }

    @Test fun targetNotMetIsShown() {
        show(500_000, 1_300_000, VerificationStatus.AUTO_VERIFIED)
        rule.onNodeWithTag("result_label").assertTextEquals("TARGET NOT MET")
    }

    @Test fun uncertainValuesRequireManualVerification() {
        show(5_000_000, 5_000_000, VerificationStatus.UNVERIFIED)
        rule.onNodeWithTag("result_label").assertTextEquals("MANUAL VERIFICATION REQUIRED")
    }
}
