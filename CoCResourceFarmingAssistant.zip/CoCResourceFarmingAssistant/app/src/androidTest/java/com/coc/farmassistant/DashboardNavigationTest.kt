package com.coc.farmassistant

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class DashboardNavigationTest {
    @get:Rule val rule = createAndroidComposeRule<MainActivity>()

    private fun open(tag: String) {
        rule.onNodeWithTag(tag).performScrollTo().performClick()
    }

    @Test fun opensHistory() {
        open("nav_history")
        rule.onNodeWithTag("history_totals").assertIsDisplayed()
    }

    @Test fun opensSettings() {
        open("nav_settings")
        rule.onNodeWithTag("save_targets").assertIsDisplayed()
    }

    @Test fun opensSimulatorAndLabelsDemoData() {
        open("nav_simulator")
        rule.onNodeWithTag("demo_label").assertIsDisplayed()
    }

    @Test fun opensAbout() {
        open("nav_about")
        rule.onNodeWithText("Version 1.0.0").performScrollTo().assertIsDisplayed()
    }
}
