package com.coc.farmassistant

import com.coc.farmassistant.domain.model.Targets
import com.coc.farmassistant.simulation.MockVillage
import com.coc.farmassistant.simulation.SimulationService
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SimulationServiceTest {
    private val sim = SimulationService()
    private val t = Targets()

    @Test fun stopsAtFirstMatch() {
        val v = listOf(MockVillage(1, 10, 10), MockVillage(2, 2_000_000, 1_000_000), MockVillage(3, 5_000_000, 5_000_000))
        val r = sim.runToEnd(sim.newSession(v), t)
        assertEquals(2, r.examinedCount)
        assertEquals(2, r.found?.id)
        assertTrue(r.finished)
    }

    @Test fun findsNoTarget() {
        val v = listOf(MockVillage(1, 10, 10), MockVillage(2, 2_000_000, 999_999))
        val r = sim.runToEnd(sim.newSession(v), t)
        assertNull(r.found)
        assertTrue(r.foundNone)
        assertEquals(2, r.examinedCount)
    }

    @Test fun stepExaminesOneVillageAtATime() {
        val s1 = sim.step(sim.newSession(listOf(MockVillage(1, 1, 1), MockVillage(2, 1, 1))), t)
        assertEquals(1, s1.examinedCount)
        assertTrue(!s1.finished)
    }

    @Test fun emptyListFinishesImmediately() {
        assertTrue(sim.newSession(emptyList()).foundNone)
    }

    @Test fun generationIsDeterministicPerSeed() {
        assertEquals(sim.generateVillages(7), sim.generateVillages(7))
        assertNotNull(sim.generateVillages(7).firstOrNull())
    }

    @Test fun changedTargetsChangeOutcome() {
        val v = sim.generateVillages(42, 25)
        val impossible = sim.runToEnd(sim.newSession(v), Targets(10_000_000, 10_000_000))
        assertNull(impossible.found)
        assertEquals(25, impossible.examinedCount)
    }
}
