package com.coc.farmassistant

import com.coc.farmassistant.domain.model.EvaluationResult
import com.coc.farmassistant.domain.model.Targets
import com.coc.farmassistant.domain.model.VerificationStatus
import com.coc.farmassistant.domain.usecase.ResourceEvaluator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ResourceEvaluatorTest {
    private val t = Targets()
    private val ok = VerificationStatus.AUTO_VERIFIED

    @Test fun exactlyAtTargets() {
        val o = ResourceEvaluator.evaluate(1_000_000, 1_000_000, ok, t)
        assertEquals(EvaluationResult.TARGET_FOUND, o.result)
        assertEquals(0L, o.goldAboveTarget)
    }
    @Test fun bothAbove() {
        val o = ResourceEvaluator.evaluate(1_200_000, 1_500_000, ok, t)
        assertEquals(EvaluationResult.TARGET_FOUND, o.result)
        assertEquals(200_000L, o.goldAboveTarget)
        assertEquals(500_000L, o.elixirAboveTarget)
    }
    @Test fun goldBelow() {
        val o = ResourceEvaluator.evaluate(900_000, 1_100_000, ok, t)
        assertEquals(EvaluationResult.TARGET_NOT_MET, o.result)
        assertEquals(listOf("Gold"), o.failedTargets)
        assertEquals(100_000L, o.goldShortfall)
    }
    @Test fun elixirBelow() {
        val o = ResourceEvaluator.evaluate(1_100_000, 999_999, ok, t)
        assertEquals(EvaluationResult.TARGET_NOT_MET, o.result)
        assertEquals(listOf("Elixir"), o.failedTargets)
        assertEquals(1L, o.elixirShortfall)
    }
    @Test fun bothBelow() {
        val o = ResourceEvaluator.evaluate(1, 2, ok, t)
        assertEquals(EvaluationResult.TARGET_NOT_MET, o.result)
        assertEquals(listOf("Gold", "Elixir"), o.failedTargets)
    }
    @Test fun missingGold() =
        assertEquals(EvaluationResult.MANUAL_VERIFICATION_REQUIRED, ResourceEvaluator.evaluate(null, 2_000_000, ok, t).result)
    @Test fun missingElixir() =
        assertEquals(EvaluationResult.MANUAL_VERIFICATION_REQUIRED, ResourceEvaluator.evaluate(2_000_000, null, ok, t).result)
    @Test fun unverifiedNeverFound() =
        assertEquals(
            EvaluationResult.MANUAL_VERIFICATION_REQUIRED,
            ResourceEvaluator.evaluate(5_000_000, 5_000_000, VerificationStatus.UNVERIFIED, t).result
        )
    @Test fun negativeRejected() =
        assertEquals(EvaluationResult.MANUAL_VERIFICATION_REQUIRED, ResourceEvaluator.evaluate(-1, 5, ok, t).result)
    @Test fun largeValues() {
        val o = ResourceEvaluator.evaluate(9_000_000_000_000L, 9_000_000_000_000L, ok, t)
        assertEquals(EvaluationResult.TARGET_FOUND, o.result)
    }
    @Test fun changedThresholds() {
        val high = Targets(2_000_000, 2_000_000)
        assertEquals(EvaluationResult.TARGET_NOT_MET, ResourceEvaluator.evaluate(1_500_000, 1_500_000, ok, high).result)
        val low = Targets(100, 100)
        assertEquals(EvaluationResult.TARGET_FOUND, ResourceEvaluator.evaluate(150, 150, ok, low).result)
    }
    @Test fun manualCorrectionCountsAsVerified() {
        val v = ResourceEvaluator.verificationFor(null, null, 1_100_000, 1_200_000, false, false)
        assertEquals(VerificationStatus.MANUALLY_CORRECTED, v)
        assertEquals(EvaluationResult.TARGET_FOUND, ResourceEvaluator.evaluate(1_100_000, 1_200_000, v, t).result)
    }
    @Test fun uncertainOcrNeedsConfirmation() {
        assertEquals(VerificationStatus.UNVERIFIED, ResourceEvaluator.verificationFor(1, 2, 1, 2, false, false))
        assertEquals(VerificationStatus.USER_CONFIRMED, ResourceEvaluator.verificationFor(1, 2, 1, 2, false, true))
        assertEquals(VerificationStatus.AUTO_VERIFIED, ResourceEvaluator.verificationFor(1, 2, 1, 2, true, false))
    }
    @Test fun unparseableFinalValuesStayUnverified() =
        assertTrue(!ResourceEvaluator.verificationFor(1, 2, null, 2, true, true).isVerified)
}
