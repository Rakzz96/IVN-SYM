package com.coc.farmassistant

import com.coc.farmassistant.domain.usecase.SettingsValidator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class SettingsValidatorTest {
    @Test fun valid() = assertEquals(1_500_000L, SettingsValidator.validateTarget("1,500,000").first)
    @Test fun negative() = assertNotNull(SettingsValidator.validateTarget("-1").second)
    @Test fun zero() = assertNotNull(SettingsValidator.validateTarget("0").second)
    @Test fun malformed() = assertNotNull(SettingsValidator.validateTarget("12abc").second)
    @Test fun empty() = assertNotNull(SettingsValidator.validateTarget("").second)
    @Test fun tooLarge() = assertNotNull(SettingsValidator.validateTarget("999,999,999").second)
    @Test fun noErrorWhenValid() = assertNull(SettingsValidator.validateTarget("1000000").second)
}
