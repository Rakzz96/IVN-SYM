package com.coc.farmassistant

import com.coc.farmassistant.recognition.OcrToken
import com.coc.farmassistant.recognition.ResourceClassifier
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ResourceClassifierTest {
    private val w = 2400
    private val h = 1080
    private fun tok(text: String, left: Int, top: Int) = OcrToken(text, left, top, left + 200, top + 50)

    @Test fun threeAlignedRowsAreConfident() {
        val d = ResourceClassifier.classify(
            listOf(tok("1,234,567", 120, 150), tok("2,000,000", 120, 230), tok("15,432", 120, 310)), w, h
        )
        assertTrue(d.confident)
        assertEquals(1_234_567L, d.gold)
        assertEquals(2_000_000L, d.elixir)
        assertEquals(15_432L, d.darkElixir)
    }

    @Test fun distractorsAreIgnored() {
        val d = ResourceClassifier.classify(
            listOf(
                tok("1,100,000", 120, 150), tok("1,200,000", 120, 230), tok("9,000", 120, 310),
                tok("+32", 120, 400),               // trophies (signed, rejected)
                tok("87", 1500, 100),               // level badge far from the panel
                tok("99,999,999", 1800, 900),       // large number outside the panel region
                tok("Available Loot", 120, 80)
            ), w, h
        )
        assertTrue(d.confident)
        assertEquals(1_100_000L, d.gold)
        assertEquals(1_200_000L, d.elixir)
    }

    @Test fun largestNumberIsNotAssumedToBeGold() {
        val d = ResourceClassifier.classify(
            listOf(tok("500,000", 120, 150), tok("3,000,000", 120, 230), tok("100", 120, 310)), w, h
        )
        assertEquals(500_000L, d.gold)
        assertEquals(3_000_000L, d.elixir)
    }

    @Test fun twoRowsAreNotConfident() {
        val d = ResourceClassifier.classify(listOf(tok("1,000,000", 120, 150), tok("1,000,000", 120, 230)), w, h)
        assertFalse(d.confident)
        assertTrue(d.notes.isNotEmpty())
    }

    @Test fun oneRowIsNotConfident() {
        val d = ResourceClassifier.classify(listOf(tok("1,000,000", 120, 150)), w, h)
        assertFalse(d.confident)
        assertNull(d.elixir)
    }

    @Test fun malformedRowIsNotConfident() {
        val d = ResourceClassifier.classify(
            listOf(tok("1,234,567", 120, 150), tok("2,00,000", 120, 230), tok("15,432", 120, 310)), w, h
        )
        assertFalse(d.confident)
        assertNull(d.elixir)
    }

    @Test fun noTextOrNonGameScreenshot() {
        val d = ResourceClassifier.classify(listOf(tok("Hello world", 100, 100)), w, h)
        assertFalse(d.confident)
        assertNull(d.gold)
        assertNull(d.elixir)
    }

    @Test fun emptyInputDoesNotCrash() {
        assertFalse(ResourceClassifier.classify(emptyList(), w, h).confident)
        assertFalse(ResourceClassifier.classify(emptyList(), 0, 0).confident)
    }

    @Test fun misalignedNumbersAreNotStacked() {
        val d = ResourceClassifier.classify(
            listOf(tok("1,000,000", 120, 150), tok("1,000,000", 700, 230), tok("5,000", 120, 700)), w, h
        )
        assertFalse(d.confident)
    }
}
