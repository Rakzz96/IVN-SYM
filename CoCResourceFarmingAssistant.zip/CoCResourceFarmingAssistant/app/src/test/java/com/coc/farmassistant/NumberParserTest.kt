package com.coc.farmassistant

import com.coc.farmassistant.util.NumberParser
import com.coc.farmassistant.util.ParseResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NumberParserTest {
    private fun valid(s: String): Long? = (NumberParser.parse(s) as? ParseResult.Valid)?.value

    @Test fun commas() = assertEquals(1_234_567L, valid("1,234,567"))
    @Test fun spaces() = assertEquals(1_234_567L, valid("1 234 567"))
    @Test fun plainInteger() = assertEquals(1000000L, valid("1000000"))
    @Test fun dotThousands() = assertEquals(1_000_000L, valid("1.000.000"))
    @Test fun largeValue() = assertEquals(9_999_999_999L, valid("9,999,999,999"))
    @Test fun empty() = assertTrue(NumberParser.parse("") is ParseResult.Invalid)
    @Test fun nullInput() = assertTrue(NumberParser.parse(null) is ParseResult.Invalid)
    @Test fun negative() = assertTrue(NumberParser.parse("-5") is ParseResult.Invalid)
    @Test fun decimal() = assertTrue(NumberParser.parse("1.5") is ParseResult.Invalid)
    @Test fun badGrouping() = assertTrue(NumberParser.parse("1,00,000") is ParseResult.Invalid)
    @Test fun garbage() = assertTrue(NumberParser.parse("abc") is ParseResult.Invalid)
    @Test fun overflow() = assertTrue(NumberParser.parse("9".repeat(30)) is ParseResult.Invalid)
    @Test fun lettersAsDigitsAreAmbiguous() {
        val r = NumberParser.parse("1,OOO,000")
        assertTrue(r is ParseResult.Ambiguous)
        assertEquals(1_000_000L, (r as ParseResult.Ambiguous).value)
    }
    @Test fun leadingZeroAmbiguous() = assertTrue(NumberParser.parse("0123") is ParseResult.Ambiguous)
    @Test fun formatting() = assertEquals("1,000,000", NumberParser.format(1_000_000))
}
