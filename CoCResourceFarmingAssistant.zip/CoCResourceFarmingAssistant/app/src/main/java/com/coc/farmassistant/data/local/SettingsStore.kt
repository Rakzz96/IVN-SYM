package com.coc.farmassistant.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.coc.farmassistant.domain.model.Targets
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import java.io.IOException

val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "settings")

data class AppSettings(
    val targets: Targets = Targets(),
    val sound: Boolean = false,
    val vibration: Boolean = false,
    val saveThumbnails: Boolean = true
)

class SettingsStore(private val dataStore: DataStore<Preferences>) {
    private object Keys {
        val GOLD = longPreferencesKey("target_gold")
        val ELIXIR = longPreferencesKey("target_elixir")
        val SOUND = booleanPreferencesKey("sound")
        val VIBRATION = booleanPreferencesKey("vibration")
        val THUMBS = booleanPreferencesKey("thumbnails")
    }

    val settings: Flow<AppSettings> = dataStore.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            AppSettings(
                targets = Targets(p[Keys.GOLD] ?: Targets.DEFAULT_GOLD, p[Keys.ELIXIR] ?: Targets.DEFAULT_ELIXIR),
                sound = p[Keys.SOUND] ?: false,
                vibration = p[Keys.VIBRATION] ?: false,
                saveThumbnails = p[Keys.THUMBS] ?: true
            )
        }

    suspend fun setTargets(t: Targets) = dataStore.edit { it[Keys.GOLD] = t.gold; it[Keys.ELIXIR] = t.elixir }
    suspend fun setSound(v: Boolean) = dataStore.edit { it[Keys.SOUND] = v }
    suspend fun setVibration(v: Boolean) = dataStore.edit { it[Keys.VIBRATION] = v }
    suspend fun setSaveThumbnails(v: Boolean) = dataStore.edit { it[Keys.THUMBS] = v }
    suspend fun reset() = dataStore.edit { it.clear() }
}
