package com.coc.farmassistant.ui.history

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.coc.farmassistant.data.repository.ScanRepository
import com.coc.farmassistant.domain.model.EvaluationResult
import com.coc.farmassistant.domain.model.ScanRecord
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class HistoryState(
    val all: List<ScanRecord> = emptyList(),
    val filter: EvaluationResult? = null,
    val error: String? = null
) {
    val visible: List<ScanRecord> get() = if (filter == null) all else all.filter { it.result == filter }
    val total: Int get() = all.size
    val matches: Int get() = all.count { it.result == EvaluationResult.TARGET_FOUND }
}

class HistoryViewModel(private val repo: ScanRepository) : ViewModel() {
    private val filter = MutableStateFlow<EvaluationResult?>(null)
    private val error = MutableStateFlow<String?>(null)

    val state: StateFlow<HistoryState> = combine(repo.observeAll(), filter, error) { all, f, e ->
        HistoryState(all, f, e)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), HistoryState())

    fun setFilter(f: EvaluationResult?) = filter.update { f }

    fun delete(id: String) = viewModelScope.launch {
        runCatching { repo.delete(id) }.onFailure { error.value = "Could not delete: ${it.message}" }
    }

    fun clearAll() = viewModelScope.launch {
        runCatching { repo.clear() }.onFailure { error.value = "Could not clear history: ${it.message}" }
    }

    suspend fun load(id: String): ScanRecord? = runCatching { repo.get(id) }.getOrNull()
}
