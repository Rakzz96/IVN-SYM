package com.coc.farmassistant.domain.usecase

import com.coc.farmassistant.util.NumberParser
import com.coc.farmassistant.util.ParseResult

object SettingsValidator {
    const val MIN_TARGET = 1L
    const val MAX_TARGET = 100_000_000L

    /** Returns the valid target, or an error message. */
    fun validateTarget(text: String): Pair<Long?, String?> =
        when (val p = NumberParser.parse(text)) {
            is ParseResult.Valid -> when {
                p.value < MIN_TARGET -> null to "Must be at least $MIN_TARGET"
                p.value > MAX_TARGET -> null to "Must be at most ${NumberParser.format(MAX_TARGET)}"
                else -> p.value to null
            }
            is ParseResult.Ambiguous -> null to "Use digits only (${p.reason.lowercase()})"
            is ParseResult.Invalid -> null to "Enter a valid whole number (${p.reason.lowercase()})"
        }
}
