package com.coc.farmassistant.recognition

import android.graphics.Bitmap
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class OcrOutput(val text: String, val tokens: List<OcrToken>, val width: Int, val height: Int)

/** On-device text recognition (bundled ML Kit model). Nothing leaves the phone. */
class OcrService {
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    suspend fun recognize(bitmap: Bitmap): OcrOutput = withContext(Dispatchers.Default) {
        val image = InputImage.fromBitmap(bitmap, 0)
        val result = Tasks.await(recognizer.process(image))
        val tokens = result.textBlocks.flatMap { it.lines }.mapNotNull { line ->
            line.boundingBox?.let { OcrToken(line.text, it.left, it.top, it.right, it.bottom) }
        }
        OcrOutput(result.text, tokens, bitmap.width, bitmap.height)
    }

    fun close() {
        runCatching { recognizer.close() }
    }
}
