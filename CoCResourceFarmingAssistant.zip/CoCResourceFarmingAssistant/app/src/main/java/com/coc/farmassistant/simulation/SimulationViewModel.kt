package com.coc.farmassistant.simulation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.coc.farmassistant.data.local.SettingsStore
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class SimulationViewModel(private val service: SimulationService, private val settings: SettingsStore) : ViewModel() {
    private val _session = MutableStateFlow(service.newSession(service.generateVillages(System.nanoTime())))
    val session: StateFlow<SimulationSession> = _session.asStateFlow()

    fun restart() { _session.value = service.newSession(service.generateVillages(System.nanoTime())) }

    fun stepNext() {
        viewModelScope.launch {
            val t = settings.settings.first().targets
            _session.update { service.step(it, t) }
        }
    }

    fun runToEnd() {
        viewModelScope.launch {
            val t = settings.settings.first().targets
            _session.update { service.runToEnd(it, t) }
        }
    }
}
