package com.coc.farmassistant.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.coc.farmassistant.ui.theme.CocColors
import com.coc.farmassistant.ui.theme.CocScaffold
import com.coc.farmassistant.ui.theme.SectionLabel

@Composable
fun SettingsScreen(vm: SettingsViewModel, onBack: () -> Unit) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    var goldText by remember(settings.targets.gold) { mutableStateOf(settings.targets.gold.toString()) }
    var elixirText by remember(settings.targets.elixir) { mutableStateOf(settings.targets.elixir.toString()) }
    var errors by remember { mutableStateOf(TargetValidation(null, null)) }
    var savedNote by remember { mutableStateOf(false) }
    var confirmClear by remember { mutableStateOf(false) }

    CocScaffold("Settings", onBack) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionLabel("TARGETS")
            OutlinedTextField(
                value = goldText, onValueChange = { goldText = it; savedNote = false },
                label = { Text("Minimum Gold") }, singleLine = true,
                isError = errors.goldError != null, supportingText = { errors.goldError?.let { Text(it) } },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth().testTag("setting_gold")
            )
            OutlinedTextField(
                value = elixirText, onValueChange = { elixirText = it; savedNote = false },
                label = { Text("Minimum Elixir") }, singleLine = true,
                isError = errors.elixirError != null, supportingText = { errors.elixirError?.let { Text(it) } },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth().testTag("setting_elixir")
            )
            Button(
                onClick = {
                    val result = vm.saveTargets(goldText, elixirText)
                    errors = result
                    savedNote = result.ok
                },
                modifier = Modifier.fillMaxWidth().testTag("save_targets")
            ) { Text("Save targets") }
            if (savedNote) Text("Targets saved.", color = CocColors.Green)

            SectionLabel("ALERTS")
            SwitchRow("Target-found sound", settings.sound, vm::setSound)
            SwitchRow("Target-found vibration", settings.vibration, vm::setVibration)

            SectionLabel("HISTORY")
            SwitchRow("Save screenshot thumbnails", settings.saveThumbnails, vm::setSaveThumbnails)
            OutlinedButton(onClick = { confirmClear = true }, modifier = Modifier.fillMaxWidth()) { Text("Clear scan history") }

            SectionLabel("RESET")
            OutlinedButton(
                onClick = { vm.resetDefaults(); errors = TargetValidation(null, null); savedNote = false },
                modifier = Modifier.fillMaxWidth().testTag("reset_defaults")
            ) { Text("Reset to default settings") }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            containerColor = CocColors.Card,
            title = { Text("Clear all history?") },
            text = { Text("This permanently deletes every saved scan.") },
            confirmButton = { TextButton(onClick = { vm.clearHistory(); confirmClear = false }) { Text("Delete all", color = CocColors.Red) } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
