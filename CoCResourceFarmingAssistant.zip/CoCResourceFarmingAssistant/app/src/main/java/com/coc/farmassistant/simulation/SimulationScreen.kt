package com.coc.farmassistant.simulation

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.coc.farmassistant.ui.theme.CocCard
import com.coc.farmassistant.ui.theme.CocColors
import com.coc.farmassistant.ui.theme.CocScaffold
import com.coc.farmassistant.ui.theme.SectionLabel
import com.coc.farmassistant.util.NumberParser

@Composable
fun SimulationScreen(vm: SimulationViewModel, onBack: () -> Unit) {
    val s by vm.session.collectAsStateWithLifecycle()

    CocScaffold("Offline Simulator", onBack) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            CocCard {
                Column(Modifier.padding(16.dp)) {
                    Text("$DEMO_LABEL", color = CocColors.Amber, fontWeight = FontWeight.ExtraBold, modifier = Modifier.testTag("demo_label"))
                    Text("Randomly generated mock villages. Not connected to the game; no real village was searched.", color = CocColors.Muted)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = vm::stepNext, enabled = !s.finished, modifier = Modifier.weight(1f)) { Text("Examine next") }
                OutlinedButton(onClick = vm::runToEnd, enabled = !s.finished, modifier = Modifier.weight(1f)) { Text("Run to end") }
            }
            OutlinedButton(onClick = vm::restart, modifier = Modifier.fillMaxWidth().testTag("sim_restart")) { Text("Restart with new mock villages") }

            Text("Villages examined: ${s.examinedCount} of ${s.villages.size}  ($DEMO_LABEL)", modifier = Modifier.testTag("sim_examined"))
            s.found?.let {
                CocCard {
                    Column(Modifier.padding(16.dp)) {
                        Text("TARGET FOUND ($DEMO_LABEL)", color = CocColors.Green, fontWeight = FontWeight.Bold)
                        Text("Mock village #${it.id}")
                        Text("Gold ${NumberParser.format(it.gold)}", color = CocColors.Gold)
                        Text("Elixir ${NumberParser.format(it.elixir)}", color = CocColors.Elixir)
                    }
                }
            }
            if (s.foundNone) {
                Text("No suitable mock village exists in this batch ($DEMO_LABEL). Restart to generate a new one.", color = CocColors.Amber)
            }
            if (s.examined.isNotEmpty()) SectionLabel("EXAMINED ($DEMO_LABEL)")
            s.examined.forEach {
                Text("#${it.id}  Gold ${NumberParser.format(it.gold)}  •  Elixir ${NumberParser.format(it.elixir)}", color = CocColors.Muted)
            }
        }
    }
}
