package com.coc.farmassistant.ui.dashboard

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.coc.farmassistant.ui.results.resultColor
import com.coc.farmassistant.ui.scanner.ScannerViewModel
import com.coc.farmassistant.ui.scanner.rememberScreenshotPicker
import com.coc.farmassistant.ui.theme.CocCard
import com.coc.farmassistant.ui.theme.CocColors
import com.coc.farmassistant.ui.theme.CocScaffold
import com.coc.farmassistant.ui.theme.ResourceIcon
import com.coc.farmassistant.ui.theme.ResourceKind
import com.coc.farmassistant.ui.theme.formatTimestamp
import com.coc.farmassistant.util.NumberParser

@Composable
fun DashboardScreen(
    vm: DashboardViewModel,
    scanner: ScannerViewModel,
    onOpenScanner: () -> Unit,
    onHistory: () -> Unit,
    onSettings: () -> Unit,
    onSimulator: () -> Unit,
    onAbout: () -> Unit
) {
    val state by vm.state.collectAsStateWithLifecycle()
    val scan by scanner.state.collectAsStateWithLifecycle()
    val pick = rememberScreenshotPicker { uri ->
        scanner.onImagePicked(uri)
        if (uri != null) onOpenScanner()
    }

    CocScaffold("CoC Resource Farming Assistant") { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(CocColors.Gold),
                    contentAlignment = Alignment.Center
                ) { Text("C", color = CocColors.Navy, fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.headlineSmall) }
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Resource Farming Assistant", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Text("Scan status: ${scan.statusText}", color = CocColors.Muted, modifier = Modifier.testTag("scan_status"))
                }
            }

            CocCard {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ResourceIcon(ResourceKind.GOLD, 36.dp); Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Minimum Gold", color = CocColors.Muted)
                            Text(NumberParser.format(state.settings.targets.gold), color = CocColors.Gold, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineSmall)
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        ResourceIcon(ResourceKind.ELIXIR, 36.dp); Spacer(Modifier.width(12.dp))
                        Column {
                            Text("Minimum Elixir", color = CocColors.Muted)
                            Text(NumberParser.format(state.settings.targets.elixir), color = CocColors.Elixir, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineSmall)
                        }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = pick, modifier = Modifier.weight(1f).testTag("dash_import")) { Text("Import Screenshot") }
                OutlinedButton(
                    onClick = {
                        onOpenScanner()
                        scanner.scan()
                    },
                    enabled = scan.bitmap != null && !scan.isScanning,
                    modifier = Modifier.weight(1f).testTag("dash_scan")
                ) { Text("Scan Screenshot") }
            }

            CocCard {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Latest scan result", color = CocColors.Muted)
                    val latest = state.latest
                    if (latest == null) {
                        Text("No saved scans yet.", modifier = Modifier.testTag("latest_empty"))
                    } else {
                        Text(latest.result.label, color = resultColor(latest.result), fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge)
                        Text("Gold ${latest.gold?.let { NumberParser.format(it) } ?: "—"}  •  Elixir ${latest.elixir?.let { NumberParser.format(it) } ?: "—"}")
                        Text(formatTimestamp(latest.timestamp), color = CocColors.Muted, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                CocCard(Modifier.weight(1f)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Saved scans", color = CocColors.Muted, style = MaterialTheme.typography.labelMedium)
                        Text("${state.totalScans}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineMedium, modifier = Modifier.testTag("total_scans"))
                    }
                }
                CocCard(Modifier.weight(1f)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Targets found", color = CocColors.Muted, style = MaterialTheme.typography.labelMedium)
                        Text("${state.foundCount}", color = CocColors.Green, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.headlineMedium, modifier = Modifier.testTag("found_count"))
                    }
                }
            }

            OutlinedButton(onClick = onHistory, modifier = Modifier.fillMaxWidth().testTag("nav_history")) { Text("Scan History") }
            OutlinedButton(onClick = onSimulator, modifier = Modifier.fillMaxWidth().testTag("nav_simulator")) { Text("Offline Simulator (DEMO DATA)") }
            OutlinedButton(onClick = onSettings, modifier = Modifier.fillMaxWidth().testTag("nav_settings")) { Text("Settings") }
            OutlinedButton(onClick = onAbout, modifier = Modifier.fillMaxWidth().testTag("nav_about")) { Text("Help & About") }
        }
    }
}
