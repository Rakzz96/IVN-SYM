package com.coc.farmassistant.data.local

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import com.coc.farmassistant.domain.model.EvaluationResult
import com.coc.farmassistant.domain.model.ScanRecord
import com.coc.farmassistant.domain.model.VerificationStatus

@Entity(tableName = "scans")
data class ScanEntity(
    @PrimaryKey val id: String,
    val timestamp: Long,
    val gold: Long?,
    val elixir: Long?,
    val goldTarget: Long,
    val elixirTarget: Long,
    val result: String,
    val verification: String,
    val manuallyCorrected: Boolean,
    @ColumnInfo(typeAffinity = ColumnInfo.BLOB) val thumbnail: ByteArray?
)

fun ScanEntity.toRecord() = ScanRecord(
    id = id, timestamp = timestamp, gold = gold, elixir = elixir,
    goldTarget = goldTarget, elixirTarget = elixirTarget,
    result = runCatching { EvaluationResult.valueOf(result) }.getOrDefault(EvaluationResult.MANUAL_VERIFICATION_REQUIRED),
    verification = runCatching { VerificationStatus.valueOf(verification) }.getOrDefault(VerificationStatus.UNVERIFIED),
    manuallyCorrected = manuallyCorrected, thumbnail = thumbnail
)

fun ScanRecord.toEntity() = ScanEntity(
    id = id, timestamp = timestamp, gold = gold, elixir = elixir,
    goldTarget = goldTarget, elixirTarget = elixirTarget,
    result = result.name, verification = verification.name,
    manuallyCorrected = manuallyCorrected, thumbnail = thumbnail
)
