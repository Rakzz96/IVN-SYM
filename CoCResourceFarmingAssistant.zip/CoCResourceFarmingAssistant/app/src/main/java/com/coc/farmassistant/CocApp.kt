package com.coc.farmassistant

import android.app.Application
import android.content.Context
import androidx.room.Room
import com.coc.farmassistant.data.local.AppDatabase
import com.coc.farmassistant.data.local.Migrations
import com.coc.farmassistant.data.local.SettingsStore
import com.coc.farmassistant.data.local.settingsDataStore
import com.coc.farmassistant.data.repository.ScanRepository
import com.coc.farmassistant.data.repository.ScanRepositoryImpl
import com.coc.farmassistant.recognition.OcrService
import com.coc.farmassistant.simulation.SimulationService

class CocApp : Application() {
    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = AppContainer(this)
    }
}

/** Manual dependency container (no DI framework needed for an app this size). */
class AppContainer(private val context: Context) {
    private val database: AppDatabase by lazy {
        Room.databaseBuilder(context, AppDatabase::class.java, "coc_scans.db")
            .addMigrations(*Migrations.ALL)
            .build()
    }
    val scanRepository: ScanRepository by lazy { ScanRepositoryImpl(database.scanDao()) }
    val settingsStore: SettingsStore by lazy { SettingsStore(context.settingsDataStore) }
    val ocrService: OcrService by lazy { OcrService() }
    val simulationService: SimulationService by lazy { SimulationService() }
}
