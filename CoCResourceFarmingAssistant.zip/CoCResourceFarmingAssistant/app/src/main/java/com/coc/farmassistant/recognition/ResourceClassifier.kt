package com.coc.farmassistant.recognition

import com.coc.farmassistant.util.NumberParser
import com.coc.farmassistant.util.ParseResult
import kotlin.math.abs

/** One recognized line of text with its pixel bounding box. */
data class OcrToken(val text: String, val left: Int, val top: Int, val right: Int, val bottom: Int) {
    val centerX: Int get() = (left + right) / 2
    val centerY: Int get() = (top + bottom) / 2
}

/** Fraction of the image (from the top-left) in which the loot panel is searched. */
data class ScanRegion(val maxX: Float, val maxY: Float) {
    companion object {
        /** Scouting screen: the "Available Loot" panel sits in the top-left. */
        val LOOT_PANEL = ScanRegion(0.45f, 0.75f)
        val FULL = ScanRegion(1f, 1f)
    }
}

data class ResourceCandidate(
    val rawText: String,
    val parse: ParseResult,
    val token: OcrToken,
    /** Assigned by position: "Gold", "Elixir", "Dark Elixir", or null if unassigned. */
    val assignedTo: String?
)

data class Detection(
    val gold: Long?,
    val elixir: Long?,
    val darkElixir: Long?,
    val confident: Boolean,
    val candidates: List<ResourceCandidate>,
    val notes: List<String>
)

/**
 * Icons are not read by OCR, so resources are classified by layout: the loot panel is a vertical
 * stack of numbers aligned on the left edge, in the fixed order Gold, Elixir, Dark Elixir.
 * Only a full three-row stack is treated as confident. Anything else needs manual verification.
 */
object ResourceClassifier {
    private val NUMERIC = Regex("^[0-9OoIlSB][0-9OoIlSB ,.'\u2019\u00A0\u202F\u2009]*$")
    private val LABELS = listOf("Gold", "Elixir", "Dark Elixir")

    fun classify(
        tokens: List<OcrToken>,
        imageWidth: Int,
        imageHeight: Int,
        region: ScanRegion = ScanRegion.LOOT_PANEL
    ): Detection {
        if (imageWidth <= 0 || imageHeight <= 0) {
            return Detection(null, null, null, false, emptyList(), listOf("Invalid image size."))
        }
        val notes = mutableListOf<String>()

        val numeric = tokens
            .filter { it.text.trim().matches(NUMERIC) && it.text.any { c -> c.isDigit() } }
            .filter { it.centerX <= imageWidth * region.maxX && it.centerY <= imageHeight * region.maxY }
            .sortedBy { it.top }

        if (numeric.isEmpty()) {
            return Detection(null, null, null, false, emptyList(), listOf("No resource-like numbers found."))
        }

        val tolX = imageWidth * 0.05f
        val maxGap = imageHeight * 0.15f
        val minGap = imageHeight * 0.01f

        // Longest vertical stack of left-aligned numbers.
        var best: List<OcrToken> = emptyList()
        for (start in numeric.indices) {
            val chain = mutableListOf(numeric[start])
            for (next in numeric.drop(start + 1)) {
                val gap = next.top - chain.last().top
                if (abs(next.left - chain.first().left) <= tolX && gap >= minGap && gap <= maxGap) {
                    chain.add(next)
                }
            }
            if (chain.size > best.size) best = chain
        }

        if (best.size > 3) {
            notes += "More than three aligned numbers found; using the first three."
            best = best.take(3)
        }

        val parsed = best.map { NumberParser.parse(it.text) }
        val values = parsed.map { (it as? ParseResult.Valid)?.value }
        val candidates = best.mapIndexed { i, t -> ResourceCandidate(t.text.trim(), parsed[i], t, LABELS.getOrNull(i)) }
        parsed.forEachIndexed { i, p ->
            if (p !is ParseResult.Valid) notes += "Row ${i + 1} (${LABELS[i]}) is unclear: \"${best[i].text.trim()}\"."
        }

        val confident = when (best.size) {
            3 -> values.all { it != null }
            2 -> {
                notes += "Only two resource rows found. It is unclear whether the second is Elixir or Dark Elixir."
                false
            }
            else -> {
                notes += "Only one resource row found. Gold and Elixir cannot be told apart."
                false
            }
        }

        return Detection(
            gold = values.getOrNull(0),
            elixir = values.getOrNull(1),
            darkElixir = if (best.size == 3) values[2] else null,
            confident = confident,
            candidates = candidates,
            notes = notes
        )
    }
}
