package com.coc.farmassistant.ui.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.coc.farmassistant.data.local.AppSettings
import com.coc.farmassistant.data.local.SettingsStore
import com.coc.farmassistant.data.repository.ScanRepository
import com.coc.farmassistant.domain.model.Targets
import com.coc.farmassistant.domain.usecase.SettingsValidator
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class TargetValidation(val goldError: String?, val elixirError: String?) {
    val ok: Boolean get() = goldError == null && elixirError == null
}

class SettingsViewModel(private val store: SettingsStore, private val repo: ScanRepository) : ViewModel() {
    val settings: StateFlow<AppSettings> =
        store.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    /** Validates both fields; saves only if both are valid. */
    fun saveTargets(goldText: String, elixirText: String): TargetValidation {
        val (gold, goldErr) = SettingsValidator.validateTarget(goldText)
        val (elixir, elixirErr) = SettingsValidator.validateTarget(elixirText)
        if (gold != null && elixir != null) {
            viewModelScope.launch { store.setTargets(Targets(gold, elixir)) }
        }
        return TargetValidation(goldErr, elixirErr)
    }

    fun setSound(v: Boolean) { viewModelScope.launch { store.setSound(v) } }
    fun setVibration(v: Boolean) { viewModelScope.launch { store.setVibration(v) } }
    fun setSaveThumbnails(v: Boolean) { viewModelScope.launch { store.setSaveThumbnails(v) } }
    fun resetDefaults() { viewModelScope.launch { store.reset() } }
    fun clearHistory() { viewModelScope.launch { repo.clear() } }
}
