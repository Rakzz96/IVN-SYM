package com.coc.farmassistant.ui

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.coc.farmassistant.AppContainer
import com.coc.farmassistant.simulation.SimulationViewModel
import com.coc.farmassistant.ui.dashboard.DashboardViewModel
import com.coc.farmassistant.ui.history.HistoryViewModel
import com.coc.farmassistant.ui.scanner.ScannerViewModel
import com.coc.farmassistant.ui.settings.SettingsViewModel

class AppViewModelFactory(private val c: AppContainer, private val appContext: Context) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = when (modelClass) {
        DashboardViewModel::class.java -> DashboardViewModel(c.scanRepository, c.settingsStore)
        ScannerViewModel::class.java -> ScannerViewModel(appContext, c.ocrService, c.scanRepository, c.settingsStore)
        HistoryViewModel::class.java -> HistoryViewModel(c.scanRepository)
        SettingsViewModel::class.java -> SettingsViewModel(c.settingsStore, c.scanRepository)
        SimulationViewModel::class.java -> SimulationViewModel(c.simulationService, c.settingsStore)
        else -> throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
    } as T
}
