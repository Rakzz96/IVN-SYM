package com.coc.farmassistant.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object CocColors {
    val Navy = Color(0xFF0B1230)
    val Card = Color(0xFF16204D)
    val Gold = Color(0xFFFFC83D)
    val Elixir = Color(0xFFD35CF0)
    val Green = Color(0xFF3DDC84)
    val Red = Color(0xFFFF6B6B)
    val Amber = Color(0xFFFFB74D)
    val Muted = Color(0xFFB8C0E0)
}

private val Scheme = darkColorScheme(
    primary = CocColors.Gold,
    onPrimary = CocColors.Navy,
    secondary = CocColors.Elixir,
    onSecondary = Color.White,
    background = CocColors.Navy,
    onBackground = Color.White,
    surface = CocColors.Card,
    onSurface = Color.White,
    surfaceVariant = CocColors.Card,
    onSurfaceVariant = CocColors.Muted,
    error = CocColors.Red
)

@Composable
fun CocTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Scheme, content = content)
}
