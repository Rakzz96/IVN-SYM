package com.coc.farmassistant.ui.history

import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.coc.farmassistant.domain.model.EvaluationResult
import com.coc.farmassistant.domain.model.ScanRecord
import com.coc.farmassistant.ui.results.resultColor
import com.coc.farmassistant.ui.theme.CocCard
import com.coc.farmassistant.ui.theme.CocColors
import com.coc.farmassistant.ui.theme.CocScaffold
import com.coc.farmassistant.ui.theme.formatTimestamp
import com.coc.farmassistant.util.NumberParser

@Composable
fun HistoryScreen(vm: HistoryViewModel, onBack: () -> Unit, onOpen: (String) -> Unit) {
    val state by vm.state.collectAsStateWithLifecycle()
    var confirmClear by remember { mutableStateOf(false) }

    CocScaffold("Scan History", onBack) { pad ->
        Column(Modifier.padding(pad).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Total scans: ${state.total}   •   Target matches: ${state.matches}", color = CocColors.Muted, modifier = Modifier.testTag("history_totals"))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = state.filter == null, onClick = { vm.setFilter(null) }, label = { Text("All") })
                EvaluationResult.entries.forEach { r ->
                    FilterChip(selected = state.filter == r, onClick = { vm.setFilter(r) }, label = { Text(r.label) })
                }
            }
            state.error?.let { Text(it, color = CocColors.Red) }
            if (state.visible.isEmpty()) {
                Text(
                    if (state.total == 0) "No scans saved yet. Scan a screenshot and tap Save Result." else "No scans match this filter.",
                    color = CocColors.Muted, modifier = Modifier.padding(top = 24.dp).testTag("history_empty")
                )
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.weight(1f)) {
                    items(state.visible, key = { it.id }) { rec -> HistoryRow(rec, onOpen = { onOpen(rec.id) }, onDelete = { vm.delete(rec.id) }) }
                }
            }
            if (state.total > 0) {
                OutlinedButton(onClick = { confirmClear = true }, modifier = Modifier.fillMaxWidth().testTag("clear_all")) { Text("Clear all history") }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            containerColor = CocColors.Card,
            title = { Text("Clear all history?") },
            text = { Text("This permanently deletes every saved scan.") },
            confirmButton = { TextButton(onClick = { vm.clearAll(); confirmClear = false }) { Text("Delete all", color = CocColors.Red) } },
            dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun HistoryRow(rec: ScanRecord, onOpen: () -> Unit, onDelete: () -> Unit) {
    CocCard(Modifier.clickable(onClick = onOpen).testTag("history_item")) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(rec.result.label, color = resultColor(rec.result), fontWeight = FontWeight.Bold)
                Text("Gold ${rec.gold?.let { NumberParser.format(it) } ?: "—"}  •  Elixir ${rec.elixir?.let { NumberParser.format(it) } ?: "—"}")
                Text(formatTimestamp(rec.timestamp), color = CocColors.Muted, style = MaterialTheme.typography.bodySmall)
            }
            IconButton(onClick = onDelete, modifier = Modifier.testTag("delete_scan")) {
                Icon(Icons.Filled.Delete, contentDescription = "Delete scan", tint = CocColors.Red)
            }
        }
    }
}

@Composable
fun HistoryDetailScreen(vm: HistoryViewModel, id: String, onBack: () -> Unit) {
    var record by remember { mutableStateOf<ScanRecord?>(null) }
    var loaded by remember { mutableStateOf(false) }
    LaunchedEffect(id) {
        record = vm.load(id)
        loaded = true
    }
    CocScaffold("Scan Details", onBack) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            val r = record
            if (r == null) {
                Text(if (loaded) "This scan no longer exists." else "Loading…", color = CocColors.Muted)
            } else {
                Text(r.result.label, color = resultColor(r.result), fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.headlineSmall)
                CocCard {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Gold: ${r.gold?.let { NumberParser.format(it) } ?: "not detected"}", color = CocColors.Gold)
                        Text("Elixir: ${r.elixir?.let { NumberParser.format(it) } ?: "not detected"}", color = CocColors.Elixir)
                        Text("Gold target at scan time: ${NumberParser.format(r.goldTarget)}")
                        Text("Elixir target at scan time: ${NumberParser.format(r.elixirTarget)}")
                        Text("Verification: ${r.verification.label}")
                        Text("Manually corrected: ${if (r.manuallyCorrected) "Yes" else "No"}")
                        Text("Scanned: ${formatTimestamp(r.timestamp)}", color = CocColors.Muted)
                    }
                }
                val bytes = r.thumbnail
                val bmp = remember(bytes) { bytes?.let { runCatching { BitmapFactory.decodeByteArray(it, 0, it.size) }.getOrNull() } }
                if (bmp != null) {
                    Image(bmp.asImageBitmap(), contentDescription = "Screenshot thumbnail", modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)))
                } else {
                    Text("No thumbnail was saved for this scan.", color = CocColors.Muted)
                }
            }
        }
    }
}
