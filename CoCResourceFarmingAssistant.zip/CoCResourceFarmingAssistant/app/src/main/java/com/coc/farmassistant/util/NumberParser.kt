package com.coc.farmassistant.util

import java.text.NumberFormat
import java.util.Locale

sealed interface ParseResult {
    data class Valid(val value: Long) : ParseResult
    /** A number was recovered, but OCR-style guesswork was involved. Needs human review. */
    data class Ambiguous(val value: Long, val reason: String) : ParseResult
    data class Invalid(val reason: String) : ParseResult
}

object NumberParser {
    private val SEPARATORS = setOf(',', '.', ' ', '\u00A0', '\u202F', '\u2009', '\'', '\u2019')
    private val CONFUSABLE = mapOf('O' to '0', 'o' to '0', 'l' to '1', 'I' to '1', 'S' to '5', 'B' to '8')
    private const val MAX_DIGITS = 15

    fun parse(raw: String?): ParseResult {
        if (raw == null || raw.isBlank()) return ParseResult.Invalid("Empty value")
        var s = raw.trim()
        if (s.any { it == '-' || it == '+' || it == '\u2212' }) return ParseResult.Invalid("Signed number")

        var ambiguousReason: String? = null
        if (s.any { it.isLetter() }) {
            if (s.any { it.isLetter() && it !in CONFUSABLE }) return ParseResult.Invalid("Contains letters")
            if (s.none { it.isDigit() }) return ParseResult.Invalid("No digits")
            s = s.map { CONFUSABLE[it] ?: it }.joinToString("")
            ambiguousReason = "Letters were read as digits"
        }
        if (s.any { !it.isDigit() && it !in SEPARATORS }) return ParseResult.Invalid("Unexpected characters")
        if (s.none { it.isDigit() }) return ParseResult.Invalid("No digits")

        val groups = s.split(*SEPARATORS.toCharArray())
        if (groups.any { it.isEmpty() }) return ParseResult.Invalid("Malformed grouping")
        if (groups.size > 1) {
            if (groups[0].length !in 1..3) return ParseResult.Invalid("Malformed grouping")
            if (groups.drop(1).any { it.length != 3 }) return ParseResult.Invalid("Malformed grouping or decimal")
        }
        val digits = groups.joinToString("")
        if (digits.length > MAX_DIGITS) return ParseResult.Invalid("Value too large")
        val value = digits.toLongOrNull() ?: return ParseResult.Invalid("Not a number")
        if (digits.length > 1 && digits.startsWith("0")) {
            ambiguousReason = ambiguousReason ?: "Leading zero"
        }
        return if (ambiguousReason != null) ParseResult.Ambiguous(value, ambiguousReason) else ParseResult.Valid(value)
    }

    fun parseOrNull(raw: String?): Long? = (parse(raw) as? ParseResult.Valid)?.value

    fun format(value: Long): String = NumberFormat.getIntegerInstance(Locale.US).format(value)
}
