package com.coc.farmassistant.ui.scanner

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.coc.farmassistant.ui.results.ResultCard
import com.coc.farmassistant.ui.results.ResourceAmountRow
import com.coc.farmassistant.ui.theme.CocCard
import com.coc.farmassistant.ui.theme.CocColors
import com.coc.farmassistant.ui.theme.CocScaffold
import com.coc.farmassistant.ui.theme.ResourceKind
import com.coc.farmassistant.ui.theme.SectionLabel
import com.coc.farmassistant.ui.theme.ZoomableImage
import com.coc.farmassistant.util.FeedbackHelper
import com.coc.farmassistant.util.NumberParser
import com.coc.farmassistant.util.ParseResult

/** Android Photo Picker: no storage permission needed. */
@Composable
fun rememberScreenshotPicker(onResult: (Uri?) -> Unit): () -> Unit {
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia(), onResult)
    return remember(launcher) {
        { launcher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }
    }
}

private fun fieldError(text: String): String? {
    if (text.isBlank()) return null
    return when (val p = NumberParser.parse(text)) {
        is ParseResult.Valid -> null
        is ParseResult.Ambiguous -> "Ambiguous: ${p.reason.lowercase()}. Retype it using digits."
        is ParseResult.Invalid -> "Not a valid amount: ${p.reason.lowercase()}"
    }
}

@Composable
fun ScannerScreen(vm: ScannerViewModel, onBack: () -> Unit, onReviewVillage: () -> Unit) {
    val state by vm.state.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val pick = rememberScreenshotPicker { uri -> vm.onImagePicked(uri) }
    var zoom by remember { mutableStateOf(false) }
    var showText by remember { mutableStateOf(false) }

    LaunchedEffect(state.pendingAlert) {
        if (state.pendingAlert) FeedbackHelper.notifyTargetFound(context, settings.sound, settings.vibration)
    }

    CocScaffold("Screenshot Scanner", onBack) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            val bmp = state.bitmap
            if (bmp != null) {
                ZoomableImage(bmp, zoomEnabled = zoom, height = 240.dp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = zoom, onCheckedChange = { zoom = it })
                    Text("  Zoom / pan (pinch and drag)", color = CocColors.Muted)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = state.cropToPanel, onCheckedChange = vm::setCropToPanel)
                    Text("  Focus on loot panel (top-left crop)", color = CocColors.Muted)
                }
            } else {
                CocCard {
                    Text(
                        "No screenshot yet. Import a screenshot of the Clash of Clans scouting screen (the village with the Available Loot panel).",
                        modifier = Modifier.padding(20.dp), color = CocColors.Muted
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = pick, modifier = Modifier.weight(1f).testTag("import_button")) { Text("Import") }
                Button(
                    onClick = vm::scan,
                    enabled = bmp != null && !state.isScanning && !state.isLoadingImage,
                    modifier = Modifier.weight(1f).testTag("scan_button")
                ) { Text("Scan Screenshot") }
            }

            if (state.isLoadingImage || state.isScanning) {
                LinearProgressIndicator(Modifier.fillMaxWidth())
                Text(state.statusText, color = CocColors.Muted)
            }
            state.error?.let { Text(it, color = CocColors.Red, modifier = Modifier.testTag("error_text")) }
            state.message?.let { Text(it, color = CocColors.Amber, modifier = Modifier.testTag("message_text")) }

            if (bmp != null) {
                SectionLabel("DETECTED VALUES (edit if wrong)")
                val det = state.detection
                val needsCheck = state.hasScanned && (det == null || !det.confident)
                if (needsCheck) {
                    Text("Needs verification: check these against the screenshot.", color = CocColors.Amber, fontWeight = FontWeight.SemiBold)
                }
                OutlinedTextField(
                    value = state.goldText, onValueChange = vm::onGoldChange,
                    label = { Text("Gold") }, singleLine = true,
                    isError = fieldError(state.goldText) != null,
                    supportingText = { fieldError(state.goldText)?.let { Text(it) } },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("gold_field")
                )
                OutlinedTextField(
                    value = state.elixirText, onValueChange = vm::onElixirChange,
                    label = { Text("Elixir") }, singleLine = true,
                    isError = fieldError(state.elixirText) != null,
                    supportingText = { fieldError(state.elixirText)?.let { Text(it) } },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth().testTag("elixir_field")
                )
                if (det != null) {
                    det.candidates.forEach { c ->
                        Text("Row → ${c.assignedTo ?: "?"}: \"${c.rawText}\"", color = CocColors.Muted, style = MaterialTheme.typography.bodySmall)
                    }
                    det.notes.forEach { Text("• $it", color = CocColors.Amber, style = MaterialTheme.typography.bodySmall) }
                }
                if (state.recognizedText.isNotBlank()) {
                    TextButton(onClick = { showText = !showText }) { Text(if (showText) "Hide recognized text" else "Show recognized text") }
                    if (showText) Text(state.recognizedText, color = CocColors.Muted, style = MaterialTheme.typography.bodySmall)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedButton(onClick = vm::confirmValues, modifier = Modifier.weight(1f).testTag("confirm_button")) { Text("Confirm values") }
                    Button(onClick = vm::evaluate, modifier = Modifier.weight(1f).testTag("evaluate_button")) { Text("Evaluate village") }
                }
            }

            AnimatedVisibility(visible = state.outcome != null) {
                state.outcome?.let { outcome ->
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        ResultCard(outcome, state.scannedAt)
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(onClick = vm::save, enabled = !state.saved, modifier = Modifier.weight(1f).testTag("save_button")) {
                                Text(if (state.saved) "Saved" else "Save Result")
                            }
                            OutlinedButton(onClick = onReviewVillage, modifier = Modifier.weight(1f).testTag("review_button")) {
                                Text("Review Village")
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    val outcome = state.outcome
    if (state.pendingAlert && outcome != null) {
        AlertDialog(
            onDismissRequest = vm::dismissAlert,
            containerColor = CocColors.Card,
            title = { Text("TARGET FOUND", color = CocColors.Green, fontWeight = FontWeight.ExtraBold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    ResourceAmountRow(ResourceKind.GOLD, "Gold", outcome.gold, "${NumberParser.format(outcome.goldAboveTarget)} above target")
                    ResourceAmountRow(ResourceKind.ELIXIR, "Elixir", outcome.elixir, "${NumberParser.format(outcome.elixirAboveTarget)} above target")
                    Text("Verification: ${outcome.verification.label}", color = CocColors.Muted)
                    TextButton(onClick = { vm.dismissAlert(); onReviewVillage() }) { Text("Review village") }
                }
            },
            confirmButton = {
                Button(
                    onClick = { vm.save(); vm.dismissAlert() },
                    colors = ButtonDefaults.buttonColors(containerColor = CocColors.Green, contentColor = CocColors.Navy)
                ) { Text("Save to history") }
            },
            dismissButton = { TextButton(onClick = vm::dismissAlert) { Text("Dismiss") } }
        )
    }
}
