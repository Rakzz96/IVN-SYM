package com.coc.farmassistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.coc.farmassistant.navigation.AppNav
import com.coc.farmassistant.ui.AppViewModelFactory
import com.coc.farmassistant.ui.theme.CocTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val container = (application as CocApp).container
        val factory = AppViewModelFactory(container, applicationContext)
        setContent {
            CocTheme { AppNav(factory) }
        }
    }
}
