package com.coc.farmassistant.domain.model

enum class EvaluationResult(val label: String) {
    TARGET_FOUND("TARGET FOUND"),
    TARGET_NOT_MET("TARGET NOT MET"),
    MANUAL_VERIFICATION_REQUIRED("MANUAL VERIFICATION REQUIRED")
}

enum class VerificationStatus(val label: String) {
    AUTO_VERIFIED("OCR confident (3 aligned resource rows)"),
    USER_CONFIRMED("Confirmed by user"),
    MANUALLY_CORRECTED("Manually corrected by user"),
    UNVERIFIED("Not verified");

    val isVerified: Boolean get() = this != UNVERIFIED
}

data class Targets(
    val gold: Long = DEFAULT_GOLD,
    val elixir: Long = DEFAULT_ELIXIR
) {
    companion object {
        const val DEFAULT_GOLD = 1_000_000L
        const val DEFAULT_ELIXIR = 1_000_000L
    }
}

data class EvaluationOutcome(
    val result: EvaluationResult,
    val gold: Long?,
    val elixir: Long?,
    val targets: Targets,
    val verification: VerificationStatus,
    val goldAboveTarget: Long,
    val elixirAboveTarget: Long,
    val goldShortfall: Long,
    val elixirShortfall: Long,
    val failedTargets: List<String>,
    val reason: String?
)

data class ScanRecord(
    val id: String,
    val timestamp: Long,
    val gold: Long?,
    val elixir: Long?,
    val goldTarget: Long,
    val elixirTarget: Long,
    val result: EvaluationResult,
    val verification: VerificationStatus,
    val manuallyCorrected: Boolean,
    val thumbnail: ByteArray?
)
