package com.coc.farmassistant.navigation

import androidx.compose.runtime.Composable
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.coc.farmassistant.simulation.SimulationScreen
import com.coc.farmassistant.simulation.SimulationViewModel
import com.coc.farmassistant.ui.about.AboutScreen
import com.coc.farmassistant.ui.attack.AttackScreen
import com.coc.farmassistant.ui.dashboard.DashboardScreen
import com.coc.farmassistant.ui.dashboard.DashboardViewModel
import com.coc.farmassistant.ui.history.HistoryDetailScreen
import com.coc.farmassistant.ui.history.HistoryScreen
import com.coc.farmassistant.ui.history.HistoryViewModel
import com.coc.farmassistant.ui.scanner.ScannerScreen
import com.coc.farmassistant.ui.scanner.ScannerViewModel
import com.coc.farmassistant.ui.settings.SettingsScreen
import com.coc.farmassistant.ui.settings.SettingsViewModel

object Routes {
    const val DASHBOARD = "dashboard"
    const val SCANNER = "scanner"
    const val ATTACK = "attack"
    const val HISTORY = "history"
    const val DETAIL = "history/{id}"
    const val SETTINGS = "settings"
    const val SIMULATOR = "simulator"
    const val ABOUT = "about"
    fun detail(id: String) = "history/$id"
}

@Composable
fun AppNav(factory: ViewModelProvider.Factory) {
    val nav = rememberNavController()
    // Scanner state is shared by the dashboard, scanner and attack screens, so it is created once here.
    val scanner: ScannerViewModel = viewModel(factory = factory)

    NavHost(navController = nav, startDestination = Routes.DASHBOARD) {
        composable(Routes.DASHBOARD) {
            val vm: DashboardViewModel = viewModel(factory = factory)
            DashboardScreen(
                vm = vm, scanner = scanner,
                onOpenScanner = { nav.navigate(Routes.SCANNER) },
                onHistory = { nav.navigate(Routes.HISTORY) },
                onSettings = { nav.navigate(Routes.SETTINGS) },
                onSimulator = { nav.navigate(Routes.SIMULATOR) },
                onAbout = { nav.navigate(Routes.ABOUT) }
            )
        }
        composable(Routes.SCANNER) {
            ScannerScreen(scanner, onBack = { nav.popBackStack() }, onReviewVillage = { nav.navigate(Routes.ATTACK) })
        }
        composable(Routes.ATTACK) { AttackScreen(scanner, onBack = { nav.popBackStack() }) }
        composable(Routes.HISTORY) {
            val vm: HistoryViewModel = viewModel(factory = factory)
            HistoryScreen(vm, onBack = { nav.popBackStack() }, onOpen = { nav.navigate(Routes.detail(it)) })
        }
        composable(Routes.DETAIL, arguments = listOf(navArgument("id") { type = NavType.StringType })) { entry ->
            val vm: HistoryViewModel = viewModel(factory = factory)
            HistoryDetailScreen(vm, entry.arguments?.getString("id").orEmpty(), onBack = { nav.popBackStack() })
        }
        composable(Routes.SETTINGS) {
            val vm: SettingsViewModel = viewModel(factory = factory)
            SettingsScreen(vm, onBack = { nav.popBackStack() })
        }
        composable(Routes.SIMULATOR) {
            val vm: SimulationViewModel = viewModel(factory = factory)
            SimulationScreen(vm, onBack = { nav.popBackStack() })
        }
        composable(Routes.ABOUT) { AboutScreen(onBack = { nav.popBackStack() }) }
    }
}
