package com.coc.farmassistant.simulation

import com.coc.farmassistant.domain.model.Targets
import kotlin.random.Random

const val DEMO_LABEL = "DEMO DATA"

data class MockVillage(val id: Int, val gold: Long, val elixir: Long)

data class SimulationSession(
    val villages: List<MockVillage>,
    val examined: List<MockVillage> = emptyList(),
    val found: MockVillage? = null,
    val finished: Boolean = false
) {
    val examinedCount: Int get() = examined.size
    val foundNone: Boolean get() = finished && found == null
}

/** Purely offline. Never touches the real game. All output is demo data. */
class SimulationService {

    fun generateVillages(seed: Long, count: Int = 25, maxResource: Long = 1_800_000L): List<MockVillage> {
        val rnd = Random(seed)
        return List(count.coerceAtLeast(0)) { i ->
            MockVillage(i + 1, rnd.nextLong(0, maxResource + 1), rnd.nextLong(0, maxResource + 1))
        }
    }

    fun newSession(villages: List<MockVillage>): SimulationSession =
        SimulationSession(villages, finished = villages.isEmpty())

    /** Examines exactly one more mock village and stops at the first match. */
    fun step(session: SimulationSession, targets: Targets): SimulationSession {
        if (session.finished) return session
        val next = session.villages.getOrNull(session.examined.size)
            ?: return session.copy(finished = true)
        val examined = session.examined + next
        val hit = next.gold >= targets.gold && next.elixir >= targets.elixir
        return session.copy(
            examined = examined,
            found = if (hit) next else null,
            finished = hit || examined.size >= session.villages.size
        )
    }

    fun runToEnd(session: SimulationSession, targets: Targets): SimulationSession {
        var s = session
        while (!s.finished) s = step(s, targets)
        return s
    }
}
