package com.coc.farmassistant.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayOutputStream
import java.io.IOException
import kotlin.math.max

object ImageLoader {
    private const val MAX_DIM = 2560

    /** Decodes with down-sampling (memory safe) and applies EXIF orientation. */
    @Throws(IOException::class)
    fun load(context: Context, uri: Uri): Bitmap {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            ?: throw IOException("Cannot open the selected image.")
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw IOException("The selected file is not a supported image.")

        var sample = 1
        while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_DIM) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw IOException("The image could not be decoded (it may be corrupt).")

        val degrees = runCatching {
            resolver.openInputStream(uri)?.use { ExifInterface(it).rotationDegrees } ?: 0
        }.getOrDefault(0)
        if (degrees == 0) return bmp
        val m = Matrix().apply { postRotate(degrees.toFloat()) }
        return Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }

    /** Crops to the top-left fraction of the image (where the loot panel is). */
    fun cropTopLeft(src: Bitmap, fracW: Float, fracH: Float): Bitmap {
        val w = (src.width * fracW).toInt().coerceIn(1, src.width)
        val h = (src.height * fracH).toInt().coerceIn(1, src.height)
        return Bitmap.createBitmap(src, 0, 0, w, h)
    }

    /** Small JPEG used for history. The full-resolution screenshot is never stored. */
    fun thumbnail(src: Bitmap, maxDim: Int = 200): ByteArray {
        val scale = maxDim.toFloat() / max(src.width, src.height)
        val small = if (scale < 1f) {
            Bitmap.createScaledBitmap(src, (src.width * scale).toInt().coerceAtLeast(1), (src.height * scale).toInt().coerceAtLeast(1), true)
        } else src
        return ByteArrayOutputStream().use { out ->
            small.compress(Bitmap.CompressFormat.JPEG, 70, out)
            out.toByteArray()
        }
    }
}
