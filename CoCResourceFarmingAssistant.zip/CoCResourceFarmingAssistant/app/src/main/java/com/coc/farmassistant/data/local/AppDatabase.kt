package com.coc.farmassistant.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.room.migration.Migration

@Database(entities = [ScanEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun scanDao(): ScanDao
}

/**
 * Register every schema change here. The database is never wiped on upgrade
 * (no fallbackToDestructiveMigration), so a version bump without a Migration fails loudly
 * instead of silently deleting the user's history.
 * Example for a future version 2: Migration(1, 2) { db -> db.execSQL("ALTER TABLE scans ADD COLUMN note TEXT") }
 */
object Migrations {
    val ALL: Array<Migration> = emptyArray()
}
