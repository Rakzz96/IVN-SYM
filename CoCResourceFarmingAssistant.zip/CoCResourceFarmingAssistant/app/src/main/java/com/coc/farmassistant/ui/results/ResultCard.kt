package com.coc.farmassistant.ui.results

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.coc.farmassistant.domain.model.EvaluationOutcome
import com.coc.farmassistant.domain.model.EvaluationResult
import com.coc.farmassistant.ui.theme.CocColors
import com.coc.farmassistant.ui.theme.ResourceIcon
import com.coc.farmassistant.ui.theme.ResourceKind
import com.coc.farmassistant.ui.theme.formatTimestamp
import com.coc.farmassistant.util.NumberParser

fun resultColor(r: EvaluationResult) = when (r) {
    EvaluationResult.TARGET_FOUND -> CocColors.Green
    EvaluationResult.TARGET_NOT_MET -> CocColors.Red
    EvaluationResult.MANUAL_VERIFICATION_REQUIRED -> CocColors.Amber
}

@Composable
fun ResourceAmountRow(kind: ResourceKind, label: String, amount: Long?, detail: String?) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        ResourceIcon(kind, 36.dp)
        Spacer(Modifier.width(12.dp))
        Column {
            Text(label, color = CocColors.Muted, style = MaterialTheme.typography.labelMedium)
            Text(
                amount?.let { NumberParser.format(it) } ?: "Not detected",
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.headlineSmall,
                color = if (kind == ResourceKind.GOLD) CocColors.Gold else CocColors.Elixir
            )
            if (detail != null) Text(detail, color = CocColors.Muted, style = MaterialTheme.typography.bodySmall)
        }
    }
}

@Composable
fun ResultCard(outcome: EvaluationOutcome, scannedAt: Long, modifier: Modifier = Modifier) {
    val color = resultColor(outcome.result)
    Card(
        modifier = modifier.fillMaxWidth().testTag("result_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = CocColors.Card),
        border = BorderStroke(2.dp, color)
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(
                outcome.result.label, color = color, fontWeight = FontWeight.ExtraBold,
                style = MaterialTheme.typography.headlineSmall, modifier = Modifier.testTag("result_label")
            )
            outcome.reason?.let { Text(it, color = CocColors.Muted) }

            val found = outcome.result == EvaluationResult.TARGET_FOUND
            val notMet = outcome.result == EvaluationResult.TARGET_NOT_MET
            ResourceAmountRow(
                ResourceKind.GOLD, "Gold detected", outcome.gold,
                when {
                    found -> "${NumberParser.format(outcome.goldAboveTarget)} above target (${NumberParser.format(outcome.targets.gold)})"
                    notMet && "Gold" in outcome.failedTargets -> "Needs ${NumberParser.format(outcome.goldShortfall)} more Gold"
                    notMet -> "Target met (${NumberParser.format(outcome.targets.gold)})"
                    else -> null
                }
            )
            ResourceAmountRow(
                ResourceKind.ELIXIR, "Elixir detected", outcome.elixir,
                when {
                    found -> "${NumberParser.format(outcome.elixirAboveTarget)} above target (${NumberParser.format(outcome.targets.elixir)})"
                    notMet && "Elixir" in outcome.failedTargets -> "Needs ${NumberParser.format(outcome.elixirShortfall)} more Elixir"
                    notMet -> "Target met (${NumberParser.format(outcome.targets.elixir)})"
                    else -> null
                }
            )
            if (notMet) Text("Failed: ${outcome.failedTargets.joinToString(" and ")}", color = CocColors.Red, fontWeight = FontWeight.SemiBold)
            Text("Verification: ${outcome.verification.label}", color = CocColors.Muted, style = MaterialTheme.typography.bodySmall)
            Text("Scanned: ${formatTimestamp(scannedAt)}", color = CocColors.Muted, style = MaterialTheme.typography.bodySmall)
        }
    }
}
