package com.coc.farmassistant.ui.scanner

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.coc.farmassistant.data.local.AppSettings
import com.coc.farmassistant.data.local.SettingsStore
import com.coc.farmassistant.data.repository.ScanRepository
import com.coc.farmassistant.domain.model.EvaluationOutcome
import com.coc.farmassistant.domain.model.ScanRecord
import com.coc.farmassistant.domain.usecase.ResourceEvaluator
import com.coc.farmassistant.recognition.Detection
import com.coc.farmassistant.recognition.OcrService
import com.coc.farmassistant.recognition.ResourceClassifier
import com.coc.farmassistant.recognition.ScanRegion
import com.coc.farmassistant.util.ImageLoader
import com.coc.farmassistant.util.NumberParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

data class ScannerUiState(
    val bitmap: Bitmap? = null,
    val cropToPanel: Boolean = true,
    val isLoadingImage: Boolean = false,
    val isScanning: Boolean = false,
    val message: String? = null,
    val error: String? = null,
    val recognizedText: String = "",
    val detection: Detection? = null,
    val goldText: String = "",
    val elixirText: String = "",
    val userConfirmed: Boolean = false,
    val outcome: EvaluationOutcome? = null,
    val scannedAt: Long = 0L,
    val saved: Boolean = false,
    val pendingAlert: Boolean = false
) {
    val hasScanned: Boolean get() = scannedAt != 0L
    val statusText: String
        get() = when {
            isLoadingImage -> "Loading screenshot…"
            isScanning -> "Scanning…"
            outcome != null -> outcome.result.label
            bitmap != null && !hasScanned -> "Screenshot ready to scan"
            hasScanned -> "Values need review"
            else -> "No screenshot loaded"
        }
}

class ScannerViewModel(
    private val appContext: Context,
    private val ocr: OcrService,
    private val repo: ScanRepository,
    private val settingsStore: SettingsStore
) : ViewModel() {

    private val _state = MutableStateFlow(ScannerUiState())
    val state: StateFlow<ScannerUiState> = _state.asStateFlow()

    val settings: StateFlow<AppSettings> =
        settingsStore.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), AppSettings())

    private var fullBitmap: Bitmap? = null
    private var ocrGold: Long? = null
    private var ocrElixir: Long? = null
    private var scanCounter = 0
    private var lastAlertKey: String? = null

    fun onImagePicked(uri: Uri?) {
        if (uri == null) {
            // Photo Picker cancelled: keep whatever was loaded before and say so.
            _state.update { it.copy(message = "No screenshot selected.") }
            return
        }
        viewModelScope.launch {
            val keepCrop = _state.value.cropToPanel
            _state.value = ScannerUiState(isLoadingImage = true, cropToPanel = keepCrop)
            try {
                val bmp = withContext(Dispatchers.IO) { ImageLoader.load(appContext, uri) }
                fullBitmap = bmp
                ocrGold = null
                ocrElixir = null
                _state.value = ScannerUiState(bitmap = bmp, cropToPanel = keepCrop)
            } catch (e: OutOfMemoryError) {
                fullBitmap = null
                _state.value = ScannerUiState(cropToPanel = keepCrop, error = "The image is too large to open on this device.")
            } catch (e: Exception) {
                fullBitmap = null
                _state.value = ScannerUiState(cropToPanel = keepCrop, error = e.message ?: "Could not open the image.")
            }
        }
    }

    fun setCropToPanel(value: Boolean) = _state.update { it.copy(cropToPanel = value) }

    fun dismissMessage() = _state.update { it.copy(message = null, error = null) }

    fun scan() {
        val bmp = fullBitmap ?: run {
            _state.update { it.copy(error = "Import a screenshot first.") }
            return
        }
        if (_state.value.isScanning) return
        viewModelScope.launch {
            _state.update { it.copy(isScanning = true, error = null, message = null, outcome = null, saved = false, userConfirmed = false) }
            try {
                val crop = _state.value.cropToPanel
                val input = withContext(Dispatchers.Default) {
                    if (crop) ImageLoader.cropTopLeft(bmp, ScanRegion.LOOT_PANEL.maxX, ScanRegion.LOOT_PANEL.maxY) else bmp
                }
                val out = ocr.recognize(input)
                if (out.text.isBlank()) {
                    _state.update {
                        it.copy(isScanning = false, scannedAt = System.currentTimeMillis(), detection = null, recognizedText = "",
                            goldText = "", elixirText = "",
                            error = "No readable text found. Try a sharper screenshot of the scouting screen, or enter the values manually.")
                    }
                    ocrGold = null; ocrElixir = null
                    scanCounter++
                    return@launch
                }
                val region = if (crop) ScanRegion.FULL else ScanRegion.LOOT_PANEL
                val det = ResourceClassifier.classify(out.tokens, out.width, out.height, region)
                ocrGold = det.gold
                ocrElixir = det.elixir
                scanCounter++
                _state.update {
                    it.copy(
                        isScanning = false, scannedAt = System.currentTimeMillis(), detection = det,
                        recognizedText = out.text,
                        goldText = det.gold?.let(NumberParser::format) ?: "",
                        elixirText = det.elixir?.let(NumberParser::format) ?: ""
                    )
                }
                evaluate()
            } catch (e: OutOfMemoryError) {
                _state.update { it.copy(isScanning = false, error = "Not enough memory to scan this image.") }
            } catch (e: Exception) {
                _state.update { it.copy(isScanning = false, error = "Text recognition failed: ${e.message ?: "unknown error"}") }
            }
        }
    }

    fun onGoldChange(text: String) = _state.update { it.copy(goldText = text, outcome = null, saved = false, userConfirmed = false) }
    fun onElixirChange(text: String) = _state.update { it.copy(elixirText = text, outcome = null, saved = false, userConfirmed = false) }

    /** User checked the values against the screenshot and vouches for them. */
    fun confirmValues() {
        _state.update { it.copy(userConfirmed = true) }
        evaluate()
    }

    fun evaluate() {
        viewModelScope.launch {
            val s = _state.value
            val gold = NumberParser.parseOrNull(s.goldText)
            val elixir = NumberParser.parseOrNull(s.elixirText)
            val verification = ResourceEvaluator.verificationFor(
                ocrGold, ocrElixir, gold, elixir, s.detection?.confident == true, s.userConfirmed
            )
            val targets = settingsStore.settings.first().targets
            val outcome = ResourceEvaluator.evaluate(gold, elixir, verification, targets)
            var alert = false
            if (outcome.result == com.coc.farmassistant.domain.model.EvaluationResult.TARGET_FOUND) {
                val key = "$scanCounter:$gold:$elixir:${targets.gold}:${targets.elixir}"
                if (key != lastAlertKey) {
                    lastAlertKey = key
                    alert = true
                }
            }
            _state.update {
                it.copy(
                    outcome = outcome, saved = false, pendingAlert = alert,
                    scannedAt = if (it.hasScanned) it.scannedAt else System.currentTimeMillis()
                )
            }
        }
    }

    fun dismissAlert() = _state.update { it.copy(pendingAlert = false) }

    fun save() {
        val s = _state.value
        val outcome = s.outcome ?: return
        if (s.saved) return
        viewModelScope.launch {
            try {
                val thumb = if (settings.value.saveThumbnails) {
                    fullBitmap?.let { b -> withContext(Dispatchers.Default) { ImageLoader.thumbnail(b) } }
                } else null
                repo.save(
                    ScanRecord(
                        id = UUID.randomUUID().toString(),
                        timestamp = if (s.scannedAt != 0L) s.scannedAt else System.currentTimeMillis(),
                        gold = outcome.gold, elixir = outcome.elixir,
                        goldTarget = outcome.targets.gold, elixirTarget = outcome.targets.elixir,
                        result = outcome.result, verification = outcome.verification,
                        manuallyCorrected = outcome.verification == com.coc.farmassistant.domain.model.VerificationStatus.MANUALLY_CORRECTED,
                        thumbnail = thumb
                    )
                )
                _state.update { it.copy(saved = true, message = "Saved to scan history.") }
            } catch (e: Exception) {
                _state.update { it.copy(error = "Could not save the result: ${e.message ?: "database error"}") }
            }
        }
    }
}
