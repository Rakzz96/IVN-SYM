package com.coc.farmassistant.ui.attack

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.coc.farmassistant.domain.model.EvaluationResult
import com.coc.farmassistant.ui.results.ResourceAmountRow
import com.coc.farmassistant.ui.scanner.ScannerViewModel
import com.coc.farmassistant.ui.theme.CocCard
import com.coc.farmassistant.ui.theme.CocColors
import com.coc.farmassistant.ui.theme.CocScaffold
import com.coc.farmassistant.ui.theme.ResourceKind
import com.coc.farmassistant.ui.theme.SectionLabel
import com.coc.farmassistant.ui.theme.ZoomableImage

private val CHECKLIST = listOf(
    "Open the village in the game and look it over yourself",
    "Check defenses and the loot the game actually shows",
    "Choose your troops and spells",
    "Decide whether to attack. This app never taps or attacks for you"
)

@Composable
fun AttackScreen(vm: ScannerViewModel, onBack: () -> Unit) {
    val state by vm.state.collectAsStateWithLifecycle()
    var reviewing by remember { mutableStateOf(false) }
    val checked = remember { mutableStateListOf(false, false, false, false) }
    val outcome = state.outcome

    CocScaffold("Attack Assistance", onBack) { pad ->
        Column(
            Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (outcome == null) {
                CocCard { Text("No evaluated scan yet. Scan a screenshot and evaluate it first.", Modifier.padding(20.dp), color = CocColors.Muted) }
            } else {
                val met = outcome.result == EvaluationResult.TARGET_FOUND
                CocCard {
                    Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            if (met) "Both targets met" else if (outcome.result == EvaluationResult.TARGET_NOT_MET) "Targets NOT met" else "Values NOT confirmed",
                            color = if (met) CocColors.Green else CocColors.Amber, fontWeight = FontWeight.Bold
                        )
                        ResourceAmountRow(ResourceKind.GOLD, "Gold", outcome.gold, "Target ${"%,d".format(outcome.targets.gold)}")
                        ResourceAmountRow(ResourceKind.ELIXIR, "Elixir", outcome.elixir, "Target ${"%,d".format(outcome.targets.elixir)}")
                        Text("Verification: ${outcome.verification.label}", color = CocColors.Muted)
                    }
                }
            }
            state.bitmap?.let { ZoomableImage(it, zoomEnabled = reviewing, height = if (reviewing) 380.dp else 200.dp) }
            Button(onClick = { reviewing = !reviewing }, modifier = Modifier.fillMaxWidth()) {
                Text(if (reviewing) "CLOSE REVIEW" else "REVIEW VILLAGE")
            }
            if (reviewing) Text("Pinch and drag the screenshot to inspect it.", color = CocColors.Muted)

            SectionLabel("MANUAL ATTACK CHECKLIST")
            CHECKLIST.forEachIndexed { i, item ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = checked[i], onCheckedChange = { checked[i] = it })
                    Text(item)
                }
            }
            Text(
                "All gameplay decisions and actions stay with you. This app only reads screenshots you import.",
                color = CocColors.Muted
            )
        }
    }
}
