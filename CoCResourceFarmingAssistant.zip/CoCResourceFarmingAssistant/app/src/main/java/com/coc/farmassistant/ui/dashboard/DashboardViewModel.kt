package com.coc.farmassistant.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.coc.farmassistant.data.local.AppSettings
import com.coc.farmassistant.data.local.SettingsStore
import com.coc.farmassistant.data.repository.ScanRepository
import com.coc.farmassistant.domain.model.ScanRecord
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

data class DashboardState(
    val settings: AppSettings = AppSettings(),
    val latest: ScanRecord? = null,
    val totalScans: Int = 0,
    val foundCount: Int = 0
)

class DashboardViewModel(repo: ScanRepository, settings: SettingsStore) : ViewModel() {
    val state: StateFlow<DashboardState> = combine(
        settings.settings, repo.observeLatest(), repo.observeCount(), repo.observeFoundCount()
    ) { s, latest, total, found -> DashboardState(s, latest, total, found) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), DashboardState())
}
