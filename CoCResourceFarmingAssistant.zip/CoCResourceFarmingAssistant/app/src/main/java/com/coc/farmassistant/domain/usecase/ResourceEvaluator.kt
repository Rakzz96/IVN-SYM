package com.coc.farmassistant.domain.usecase

import com.coc.farmassistant.domain.model.EvaluationOutcome
import com.coc.farmassistant.domain.model.EvaluationResult
import com.coc.farmassistant.domain.model.Targets
import com.coc.farmassistant.domain.model.VerificationStatus
import kotlin.math.max

object ResourceEvaluator {

    /**
     * Decides how trustworthy the final values are.
     * Values the user typed or changed always count as a deliberate correction.
     */
    fun verificationFor(
        ocrGold: Long?,
        ocrElixir: Long?,
        finalGold: Long?,
        finalElixir: Long?,
        ocrConfident: Boolean,
        userConfirmed: Boolean
    ): VerificationStatus {
        if (finalGold == null || finalElixir == null) return VerificationStatus.UNVERIFIED
        val corrected = finalGold != ocrGold || finalElixir != ocrElixir
        return when {
            corrected -> VerificationStatus.MANUALLY_CORRECTED
            ocrConfident -> VerificationStatus.AUTO_VERIFIED
            userConfirmed -> VerificationStatus.USER_CONFIRMED
            else -> VerificationStatus.UNVERIFIED
        }
    }

    fun evaluate(
        gold: Long?,
        elixir: Long?,
        verification: VerificationStatus,
        targets: Targets
    ): EvaluationOutcome {
        fun manual(reason: String) = EvaluationOutcome(
            result = EvaluationResult.MANUAL_VERIFICATION_REQUIRED,
            gold = gold, elixir = elixir, targets = targets, verification = verification,
            goldAboveTarget = 0, elixirAboveTarget = 0, goldShortfall = 0, elixirShortfall = 0,
            failedTargets = emptyList(), reason = reason
        )

        if (gold == null && elixir == null) return manual("Gold and Elixir are both missing.")
        if (gold == null) return manual("Gold is missing or unreadable.")
        if (elixir == null) return manual("Elixir is missing or unreadable.")
        if (gold < 0 || elixir < 0) return manual("Resource amounts cannot be negative.")
        if (!verification.isVerified) return manual("Values are not verified. Check them against the screenshot, then confirm.")

        val goldOk = gold >= targets.gold
        val elixirOk = elixir >= targets.elixir
        val failed = buildList {
            if (!goldOk) add("Gold")
            if (!elixirOk) add("Elixir")
        }
        return EvaluationOutcome(
            result = if (goldOk && elixirOk) EvaluationResult.TARGET_FOUND else EvaluationResult.TARGET_NOT_MET,
            gold = gold, elixir = elixir, targets = targets, verification = verification,
            goldAboveTarget = max(0L, gold - targets.gold),
            elixirAboveTarget = max(0L, elixir - targets.elixir),
            goldShortfall = max(0L, targets.gold - gold),
            elixirShortfall = max(0L, targets.elixir - elixir),
            failedTargets = failed,
            reason = null
        )
    }
}
