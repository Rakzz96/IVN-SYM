package com.coc.farmassistant.ui.about

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.coc.farmassistant.ui.theme.CocCard
import com.coc.farmassistant.ui.theme.CocColors
import com.coc.farmassistant.ui.theme.CocScaffold
import com.coc.farmassistant.ui.theme.SectionLabel

@Composable
fun AboutScreen(onBack: () -> Unit) {
    CocScaffold("Help & About", onBack) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionLabel("HOW TO USE")
            CocCard {
                Text(
                    "1. Play normally and take a screenshot of the scouting screen (the one showing Available Loot).\n" +
                        "2. Import it here, then tap Scan Screenshot.\n" +
                        "3. Check the detected Gold and Elixir against the screenshot. Correct them if needed.\n" +
                        "4. Read the result: TARGET FOUND, TARGET NOT MET, or MANUAL VERIFICATION REQUIRED.\n" +
                        "5. Save it to history if you want a record. Any attack decision is yours.",
                    modifier = Modifier.padding(16.dp)
                )
            }
            SectionLabel("HOW RESOURCES ARE TOLD APART")
            CocCard {
                Text(
                    "Text recognition cannot see icons. The app reads the stacked numbers in the loot panel in game order: " +
                        "Gold, then Elixir, then Dark Elixir. It only trusts a result when it finds all three rows. " +
                        "Anything else is flagged for you to check.",
                    modifier = Modifier.padding(16.dp)
                )
            }
            SectionLabel("PRIVACY")
            CocCard {
                Text(
                    "Screenshots are read on this device. Nothing is uploaded, and no account or game login is needed. " +
                        "The app uses the Android Photo Picker, so it never gets broad access to your photos. " +
                        "Only a small thumbnail is kept in history, and you can turn that off in Settings.",
                    modifier = Modifier.padding(16.dp)
                )
            }
            SectionLabel("WHAT THIS APP DOES NOT DO")
            CocCard {
                Text(
                    "It does not tap, search, attack, or control the game in any way. " +
                        "The simulator uses mock villages labelled DEMO DATA and never connects to the game.",
                    modifier = Modifier.padding(16.dp)
                )
            }
            Text("Version 1.0.0", color = CocColors.Muted)
        }
    }
}
