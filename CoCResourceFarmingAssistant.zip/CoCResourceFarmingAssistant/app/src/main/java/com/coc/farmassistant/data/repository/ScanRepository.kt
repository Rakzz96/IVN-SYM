package com.coc.farmassistant.data.repository

import com.coc.farmassistant.data.local.ScanDao
import com.coc.farmassistant.data.local.toEntity
import com.coc.farmassistant.data.local.toRecord
import com.coc.farmassistant.domain.model.ScanRecord
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

interface ScanRepository {
    fun observeAll(): Flow<List<ScanRecord>>
    fun observeLatest(): Flow<ScanRecord?>
    fun observeCount(): Flow<Int>
    fun observeFoundCount(): Flow<Int>
    suspend fun get(id: String): ScanRecord?
    suspend fun save(record: ScanRecord)
    suspend fun delete(id: String)
    suspend fun clear()
}

class ScanRepositoryImpl(private val dao: ScanDao) : ScanRepository {
    override fun observeAll() = dao.observeAll().map { list -> list.map { it.toRecord() } }
    override fun observeLatest() = dao.observeLatest().map { it?.toRecord() }
    override fun observeCount() = dao.observeCount()
    override fun observeFoundCount() = dao.observeFoundCount()
    override suspend fun get(id: String) = dao.get(id)?.toRecord()
    override suspend fun save(record: ScanRecord) = dao.insert(record.toEntity())
    override suspend fun delete(id: String) = dao.delete(id)
    override suspend fun clear() = dao.clear()
}
