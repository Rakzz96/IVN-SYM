# CoC Resource Farming Assistant

Android app (Kotlin, Jetpack Compose, Material 3, MVVM) that reads a Clash of Clans **scouting screenshot** on-device,
detects Gold and Elixir, and tells you TARGET FOUND / TARGET NOT MET / MANUAL VERIFICATION REQUIRED.
You stay in manual control of the game. The app never taps, searches or attacks.

## Honest status

| Item | Status |
|---|---|
| Core logic (parser, evaluator, OCR classifier, simulator, settings validation) | Compiled with kotlinc 2.0.21 and **51 unit tests ran and passed** (see below) |
| Android layer (Compose UI, Room, DataStore, ML Kit, navigation) | **Written but NOT compiled or run.** The build environment had no Android SDK or Maven access |
| Instrumented UI tests (`androidTest`) | Written, **never run** |
| APK | **Not built.** No APK path exists yet. Build it with one of the options below |
| OCR accuracy on real screenshots | **Untested.** The classifier is verified only against synthetic OCR output |

Expect to fix a few compile errors on the first real build. Paste them back and they can be fixed quickly.

## Build the APK without a PC (GitHub Actions)
1. Create a GitHub repository and upload this folder's contents (keep `.github/workflows/build-apk.yml`).
2. Open the **Actions** tab, choose **Build debug APK**, tap **Run workflow**.
3. When it finishes, download the artifact **CoC-Resource-Farming-Assistant-debug-apk** from the run page.
   The file inside is `app-debug.apk` (built at `app/build/outputs/apk/debug/app-debug.apk` on the runner).
4. Copy it to the Android phone and install it (allow "Install unknown apps" for your file manager or browser).

## Build with Android Studio (PC)
1. Open this folder in Android Studio (Ladybug or newer), let Gradle sync.
2. Run on a USB-debugging phone, or **Build > Build APK(s)**.
   Output: `app/build/outputs/apk/debug/app-debug.apk`.
3. Install: `adb install -r app/build/outputs/apk/debug/app-debug.apk`.

There is no Gradle wrapper jar in this zip. Android Studio and the GitHub workflow both supply Gradle 8.9 themselves.

## How recognition works (and its limits)
OCR cannot see the gold/elixir icons. The loot panel is a vertical stack of left-aligned numbers in the fixed order
**Gold, Elixir, Dark Elixir**. The classifier finds that stack in the top-left of the screenshot and assigns values by row order.
- Three clean rows: treated as confident.
- Two rows, one row, malformed digits, or no numbers: **never** treated as verified. You must correct or confirm the values.
- Typed corrections are kept separate from OCR values and are recorded as "manually corrected".
- Layout assumptions (panel in top-left, landscape scouting screen) may need tuning on real screenshots. See `ScanRegion` in
  `recognition/ResourceClassifier.kt`. Make a lower-quality screenshot test first.

## Project layout
`data/local` (Room, DataStore) · `data/repository` · `domain/model` · `domain/usecase` · `recognition` (ML Kit + classifier) ·
`simulation` (offline demo) · `ui/*` (dashboard, scanner, results, attack, history, settings, about) · `navigation` · `util`.

## Tests
- Unit tests: `app/src/test` (parser, evaluator incl. exact/above/below targets, missing/ambiguous/manual values, large values,
  changed thresholds, classifier, simulator found/not found, settings validation). Run with `gradle :app:testDebugUnitTest`.
- UI tests: `app/src/androidTest` (result card states, dashboard navigation). Run with `gradle :app:connectedDebugAndroidTest` on a device.
- Not yet written: Photo Picker cancellation UI test, settings persistence UI test, history deletion UI test.

## Known limitations
- Scanner state (loaded screenshot, values) is in memory. If Android kills the app process, the scanner resets. Saved history and settings persist.
- "Crop" is a fixed top-left loot-panel crop (toggle), not a free-form selection tool.
- Database is version 1; future schema changes must add a `Migration` in `data/local/AppDatabase.kt`.
